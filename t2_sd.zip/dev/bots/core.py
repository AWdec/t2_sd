# SIMULACION DE VARIOS MOTEHUESILLEROS QUE:
# VENDEN, CADA 5-35 SEGUNDOS + 3 seg, CON UNA PROB DEL 40%.

import sys
sys.path.append('../')
import numpy as np
import bd.core as bd
import linecache
import config
import math
import funcs.core as fc
import time
import threading
from producers import producir 

# CANTIDAD MH A USAR
N = 25

# REGISTRAR M = 2000 MH.Este es el máximo valor para N.
M = 25
mailtypes = ["gmail", "hotmail", "outlook", "protonmail", "mail.udp"]
domaintypes = ["com", "edu", "cl", "gov", "us", "org", "io", "com.ar", "com.br", "ve", "es", "fr"]
charTypes = ["", ".", "", "_", "__", "xx"]

# SOLO SE REGISTRAN 1 VEZ, HACIENDO UNA CONSULTA A LA BD SI ES QUE NO ESTÁN CREADOS.
# ESTE TIPO DE USUARIOS TENDRÁN SU USERTYPE = 2
while len(bd.getBotsMH()) < M:
  
  randomName = linecache.getline('names.txt', math.trunc(np.random.uniform(0, config.NAMES_LEN)))
  randomName = randomName.strip()

  randomYear = str(math.trunc(np.random.uniform(1920, 2010)))
  randomTypeMail = mailtypes[math.trunc(np.random.uniform(0, len(mailtypes)))]
  randomDomain = domaintypes[math.trunc(np.random.uniform(0, len(domaintypes)))]
  randomChar = charTypes[math.trunc(np.random.uniform(0, len(charTypes)))]


  data = {
   'nombre': randomName,
   'email': f"{randomName}{randomChar}{randomYear}@{randomTypeMail}.{randomDomain}",
   'password': fc.getRandomStr(8),
   'ventas': 0,
   'stock':  '{"mote": 500, "huesillo": 250, "chancaca": 120}',
   'usertype': config.BOT_USERTYPE
  }

  bd.regMH(data)

print('Cantidad de usuarios chequeados!')

bots = bd.getBotsMH()

def botThread(botData):
 random_secs = math.trunc(np.random.uniform(5, 35))
 print(f'Me ejecutaré en {random_secs} segundos\n')
 time.sleep(random_secs)
 #print(f'Soy BOT ID {botData[0]}')
 data = ["", botData[1], botData[2]]
 cantidadAVender = math.trunc(np.random.uniform(1, 15))
 opid = str(fc.getTimeStamp()) + str(np.random.uniform(1, 999999))
 
 if bd.opExists(opid):
    return
 
 producir.vender(data, cantidadAVender, opid)
 bd.usedOp(opid)

 # repone stock siempre que se le acabe:)
 if bd.sinStock(botData[2]):
   arr_extra = [math.trunc(np.random.uniform(80, 120)),
                math.trunc(np.random.uniform(30, 50)),
                math.trunc(np.random.uniform(15, 30))]
   opidstock = str(fc.getTimeStamp()) + str(np.random.uniform(1, 999999))

    
   if bd.opExists(opidstock):
    return
 
   producir.addStock(data, arr_extra, opidstock)
   bd.usedOp(opidstock)
   

# 0 = id, 1 = nombre, 2 = email, 3 = password, 4 = ventas, 5 = stock, 6 =usertype
prob = 40


while True:
    counter = 0
    for bot in bots:

        if counter >= N:
           break

        prob = np.random.uniform(0, 100)
        
        if prob <= (100 - prob):
            continue
        
        #print(f'Soy el bot {bot[0]}')

        threading.Thread(target=botThread, args=(bot,)).start()

        counter += 1
    
    time.sleep(3)
  




