import asyncio
import sys
import producir

sys.path.append('../')
import funcs.core as fc
import bd.core as bd
import config

import producer

# data[0] => id, [1] => nombre, [2] => email, [3] => password, [4] => ventas, [5] => stock
def nextMenu(data): # data => es la fila del usuario en la BD(tabla MH)
 print('1. Reponer Stock')
 print('2. Simular venta')

 nextStep = input('\nEscoja una opcion:  ')

 while nextStep != "1" and nextStep != "2":
  nextStep = input('Escoga una opcion válida(solo 1 o 2):  ')

# stock
 if nextStep == "1":
  #print('Repuesto!')
  cantidadExtraMote = input('Ingrese la cantidad de mote que desea reponer: ')
  cantidadExtraHuesillo = input('Ingrese la cantidad de huesillo que desea reponer: ')
  cantidadExtraChancaca = input('Ingrese la cantidad de chancaca que desea reponer: ')

  while int(cantidadExtraMote) < 0  or int(cantidadExtraHuesillo) < 0 or int(cantidadExtraChancaca) < 0:
   print("Las cantidades deben ser POSITIVAS !\n")
   cantidadExtraMote = input('Ingrese la cantidad de mote que desea reponer: ')
   cantidadExtraHuesillo = input('Ingrese la cantidad de huesillo que desea reponer: ')
   cantidadExtraChancaca = input('Ingrese la cantidad de chancaca que desea reponer: ')

  arr_extra = [cantidadExtraMote, cantidadExtraHuesillo, cantidadExtraChancaca]
  opid = str(fc.getTimeStamp())

  producir.addStock(data, arr_extra, opid)

  res = bd.opExists(opid)
  while not res:
   res = bd.opExists(opid)

  res =  (bd.getOpData(opid)[0])[1] # [0] OPID, [1] RESPONSE , [2] USED
  
  if res == "0":
   print('\n[INFO] Se ha añadido el stock satisfactoriamente')
  elif res == "-1":
   print('\n[INFO] Ha ocurrido un error al añadir stock.')
  
  # elimina op en bd
  bd.usedOp(opid)

# venta
 elif nextStep == '2':
  cantidadAVender = input('Escriba la cantidad de ventas que desea simular: ')

  # no puede ser str ni negativo
  while not fc.canParseAsInt(cantidadAVender):
    cantidadAVender = input('Escriba la cantidad de ventas que desea simular: ')
  
  while int(cantidadAVender) <= 0:
    cantidadAVender = input('Escriba la cantidad de ventas que desea simular: ')
  
  # para llevar registro de la operacion
  opid = str(fc.getTimeStamp())
  
  producir.vender(data, cantidadAVender, opid)

  res = bd.opExists(opid)
  while not res:
   res = bd.opExists(opid)

  res =  (bd.getOpData(opid)[0])[1] # [0] OPID, [1] RESPONSE , [2] USED
  
  if res == "-1":
   print(f'\n[INFO] Has vendido satisfactoriamente {cantidadAVender} motes con huesillo')
  else: # para esta operacion, cualquier valor distinto de -1 se considerará error y corresponderá a la máx cantidad que se pueda vender.
   print(f'\n[INFO] No puedes vender esa cantidad debido a tu stock. Lo máximo que puedes vender es {res} motes con huesillo.')


#autenticado = False

print('1. Ingresar a MAMOCHI')
print('2. Inscribirse a MAMOCHI')

nextStep = input('\nEscoja una opcion:  ')

while nextStep != "1" and nextStep != "2":
 nextStep = input('Escoga una opcion válida(solo 1 o 2):  ')

# ingresar
if nextStep == "1":
  data = {
    'email': input('Ingrese email:  '),
    'password': input('Ingrese contraseña:  ')
  }

  res = bd.login(data["email"], data["password"])

  if res:
   data = bd.getMHData(data["email"])
   print(f'\n[INFO] Has ingresado correctamente {data[0][1]} !')
   print('---------------------------------------')
   nextMenu(data[0])
  
  else:
   print('[INFO] El usuario no existe o las credenciales son incorrectas!')
  
# inscribirse
elif nextStep == "2":
  data = {
   'nombre': input('Ingrese nombre:  '),
   'email': input('Ingrese email:  '),
   'mensaje': input('Ingrese mensaje:  '),
   'opid': str(fc.getTimeStamp()),
   'usertype': config.NORMAL_USERTYPE
  }
  
  prioritario = str(input('Desea pagar para acelerar el proceso?(Y/N):  ')).lower()
  
  while prioritario != 'y' and prioritario != 'n':
   prioritario = str(input('Desea pagar para acelerar el proceso?(Y/N):  ')).lower()

  prioritario = True if prioritario == 'y' else False

  producir.inscribirse(data, prioritario)

  res = bd.opExists(data["opid"])
  while not res:
   res = bd.opExists(data["opid"])

  res =  (bd.getOpData(data["opid"])[0])[1] # [0] OPID, [1] RESPONSE , [2] USED
  
  if res == "0":
   print('\n[INFO] Has ingresado exitosamente a MAMOCHI!')
  elif res == "-1":
   print('\n[INFO] Este email ya pertenece a un motehuesillero existente.')
  
  # elimina usedOp. La idea era mantener una comunicacion mediante sharedmemory en la db
  bd.usedOp(data["opid"])

def core():
 # resto de funciones que puede hacer un motehuesillero: ventas y stock
 print('')