import asyncio
import sys
sys.path.append('../')  # Agrega la ruta al directorio padre
import producer
import funcs.core as fc
import bd.core as bd
import numpy as np

# Se espera que data sea de la forma:
# data = {
#   nombre: ""
#   email: ""
#   mensaje: ""
# }

# PRODUCIR FUNCIONA COMO UN DISPATCHER

def inscribirse(data, prioritario=False):
    topic = 'inscripciones'
    indicator = '1' if prioritario else '0'
    key = f'{indicator}.{fc.getTimeStamp()}'
    
    # publicamos al topico
    asyncio.run(producer.send_one(topic, data, key))

def addStock(userData, dataArr, opid):
    fullData = {
        'nombre': userData[1],
        'email': userData[2],
        'dataArr': dataArr,
        'opid': opid
    }

    topic = 'stock'

    # publicar
    asyncio.run(producer.send_one(topic, fullData, np.random.uniform(1, 10000)))


def vender(userData, cantidad, opid):
    fullData = {
        'nombre': userData[1],
        'email': userData[2],
        'cantidad': cantidad,
        'opid': opid
    }

    topic = 'ventas'

    asyncio.run(producer.send_one(topic, fullData, np.random.uniform(1, 10000)))
    



