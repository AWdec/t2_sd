import config
from kafka.admin import KafkaAdminClient, NewTopic
import kafka

admin_client = KafkaAdminClient(bootstrap_servers=config.BROCKERS[0])

topicNames = ['inscripciones', 'stock', 'ventas']
topic_list = []

consumer = kafka.KafkaConsumer(group_id='test', bootstrap_servers=[config.BROCKERS[0]])
toDelete = []
mustAdd = 0

# agregar topicos solo si no están

# Eliminar en caso de haber agregado algo sin querer
for topicName in consumer.topics():
  if topicName not in topicNames:
    toDelete.append(topicName)

if len(toDelete) > 0:
   admin_client.delete_topics(topics=toDelete)

# si no se han agregado todos los topicos, pues se agregan los faltantes
toAdd = []

for topicName in topicNames:
  if topicName not in consumer.topics():
    toAdd.append(NewTopic(name=topicName, num_partitions=1, replication_factor=1))

if len(toAdd) > 0: 
   admin_client.create_topics(new_topics=toAdd)

