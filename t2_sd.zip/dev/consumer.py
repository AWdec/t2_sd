from aiokafka import AIOKafkaConsumer
import asyncio
import config

async def consume(topicName, funcs):
    consumer = AIOKafkaConsumer(
        topicName,
        bootstrap_servers=config.BROCKERS[0])
    await consumer.start()

    try: 
        # cada vez que suceda un mensaje se activa
        async for msg in consumer: 
            #msg_content = (msg.value).decode('utf-8')
            #msg_key = (msg.key).decode('utf-8')

            for func in funcs:
                func(msg.value, msg.key)

    finally:
        await consumer.stop()

