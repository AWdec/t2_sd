import asyncio
import sys
sys.path.append('../')

import consumer
import funcs.core as fc
import bd.core as bd

topicName = 'ventas'

def tryVenta(data):
 cantidadVenta = int(data["cantidad"])
 opid = data['opid']
 userStock =  bd.getStock(data["email"])
 
 pudoVender = bd.disminuirStock(data["email"], cantidadVenta) # si pudo disminuir stock, entonces pudo vender esa cantidad. De lo contrario, signifiac que le faltaba stock.

 if pudoVender:
   bd.modifyVentas(data["email"], cantidadVenta)
   bd.writeOp(data["opid"], "-1") # en este caso, -1 se considera éxito.
   return True

 # no puede vender esa cantidad por falta de stock
 else:
   maxCantidad = bd.getMaxVentas(data["email"])
   bd.writeOp(data["opid"], str(maxCantidad))
   return False

 

def core(data, key):

 ndata = fc.deserializeObj(data)
 
 res = tryVenta(ndata)
 
 if res:
    print('\n\n------------- REGISTRO DE VENTA ----------------')
    print(f'Nombre: {ndata["nombre"]}, email: {ndata["email"]}')
    print(f'Ha vendido {ndata["cantidad"]} motes con huesillo')
    print(f'Fecha: {fc.getDate()}')
    print('------------------------------------------------')

funcs = [core]

asyncio.run(consumer.consume(topicName, funcs))
