import asyncio
import sys
sys.path.append('../')

import funcs.core as fc
import consumer
import bd.core as bd

topicName = 'stock'

def aumentarStock(data):
 bd.modifyStock(data["email"], [int(data["dataArr"][0]), int(data["dataArr"][1]), int(data["dataArr"][2])])
 bd.writeOp(data["opid"], "0")
 

def core(data, key): 

 ndata = fc.deserializeObj(data)

 print('--------- SOLICITUD DE REPOSICIÓN STOCK --------')
 print(f'Nombre: {ndata["nombre"]}, Email: {ndata["email"]}')
 print('Ha solicitado aumentar su stock en las siguientes cantidades:\n')
 print(f'Mote: {ndata["dataArr"][0]}[gr], Huesillo: {ndata["dataArr"][1]}[gr], Chancaca: {ndata["dataArr"][2]}[gr]')
 print(f'Fecha: {fc.getDate()}')
 print('------------------------------------------------')
 print('\n')
 print('\n')

 aumentarStock(ndata)

funcs = [core]

asyncio.run(consumer.consume(topicName, funcs))
