import asyncio
import sys
sys.path.append('../')
import numpy as np
import bd.core as bd

import consumer
import funcs.core as fc
import mail.core as mail

topicName = 'inscripciones'

def inscribir(data, prior):
 # llamamos BD para ingresar usuario si es que su EMAIL no existe
 # creamos pw aleatoria
 # enviamos datos a email
 # si prior = True lo adelantamos antes del primer no prioritario
 # el efecto de esto solo se veria si hubiesen muchisimas inscripciones
 # la cola de motehuesilleros por inscribir estará en la BD

 fullData = {
  'nombre': data["nombre"],
  'email': data["email"],
  'password': fc.getRandomStr(8),
  'ventas': 0,
  'stock':  '{"mote": 500, "huesillo": 250, "chancaca": 120}',
  'usertype': data["usertype"]
 }

 state = 'Aceptada'
 
 if not bd.checkMHexists(fullData["email"]):
  bd.regMH(fullData)
  bd.writeOp(data["opid"], '0')
  mail.send(str(fullData["email"]), 'Inscripcion exitosa en MAMOCHI', f'Bienvenido a MAMOCHI {fullData["nombre"]}, es un gusto tenerte con nosotros!. Tu contrasenia es {fullData["password"]}')

 else:
  # el usuario ya existia
  bd.writeOp(data["opid"], '-1')
  state = 'Rechazada'
  
 data = {
   'nombre': data["nombre"],
   'email': data["email"],
   'mensaje': data["mensaje"],
   'estado': state,
   'fecha': fc.getDate()
 }
 bd.writeHistorial(data)
  
# apiMail.send(fullData)
# log: ('satisfactorio')
  

def core(data, key):
 
 #print(type(data))
 

 ndata = fc.deserializeObj(data)
 nkey = fc.deserializeStr(key)

 key_arr = nkey.split('.') 
 prior = 'Si' if  key_arr[0] == '1' else 'No'
 
 
 print('------------ SOLICITUD DE INSCRIPCION ----------')
 print(f'Nombre: {ndata["nombre"]}')
 print(f'Email: {ndata["email"]}')  
 print(f'Mensaje: {ndata["mensaje"]}')
 print(f'Fecha: {fc.getDate()}')
 print(f'Prioritario: {prior}')
 print(f'Numero solicitud: {key_arr[1]}')
 print('------------------------------------------------')
 print('\n')
 print('\n')
 
 
 priorbool = True if key_arr[0] == '1' else False
 inscribir(ndata, priorbool)

 
funcs = [core] # callbacks

asyncio.run(consumer.consume(topicName, funcs))

