# global vars
LOCAL_IP = '127.0.0.1'
BROCKERS = [
 f'{LOCAL_IP}:9092'
]
 # ESTRUCTURA MOTE CON HUESILLO, EN CUANTO A INGREDIENTES NECESARIOS:
UNIT_STOCK = {
    "mote": 10, 
    "huesillo": 5, 
    "chancaca": 1
}
GANANCIA_POR_VENTA = 500

# BOTS CONFIG
BOT_USERTYPE = "2"
NORMAL_USERTYPE = "1"
NAMES_LEN = 7944

# MAIL API
mail = "eduardo.global7@gmail.com"
pw = "akohrhbagyyrezkr"