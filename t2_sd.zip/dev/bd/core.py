import math
import psycopg2
import sys
import json
sys.path.append('../')

import config

conn = psycopg2.connect(
    host=config.LOCAL_IP,
    database="mamochi",
    user="postgres",
    password="bd123",
    port=5432)


def getBotsMH():
    cursor = conn.cursor()

    consulta = f"SELECT * FROM MH WHERE usertype = '{config.BOT_USERTYPE}'"

    cursor.execute(consulta)
    resultados = cursor.fetchall()

    #for fila in resultados:
     #print(fila)

    cursor.close()

    return resultados

# get MH data
def getMHData(email):
    cursor = conn.cursor()

    consulta = f"SELECT * FROM MH WHERE email = '{str(email)}'"

    cursor.execute(consulta)
    resultados = cursor.fetchall()

    #for fila in resultados:
     #print(fila)

    cursor.close()

    return resultados

# registrar MoteHuesillero
def regMH(data):
 # Consulta SQL para la inserción de datos
    cursor = conn.cursor()

    consulta = "INSERT INTO MH (nombre, email, password, ventas, stock, usertype) VALUES (%(nombre)s, %(email)s, %(password)s, %(ventas)s, %(stock)s, %(usertype)s) RETURNING id;"

    cursor.execute(consulta, data)
    conn.commit() 

# registrar bot
def generarBotMH(data):
    regMH(data)

# chequear si ya existe
def checkMHexists(email):
 return len(getMHData(email)) > 0

def getVentas(email):
 ventas = 0
 data = getMHData(email)
 
 # asumiendo que email nunca se repite y que está bn implementado
 for fila in data:
   ventas = int(fila[4])
 
 return ventas
 
def modifyVentas(email, aumento):
  cur = conn.cursor()

  newVentas = getVentas(email) + aumento
  query = f"UPDATE MH SET ventas = '{newVentas}' WHERE email = '{email}'"
  cur.execute(query)
  conn.commit()
  cur.close()

def getStock(email):
 stock = ''
 data = getMHData(email)
 
 # asumiendo que email nunca se repite y que está bn implementado
 for fila in data:
   stock = str(fila[5])

 stock = stock.replace("'", '"')

 return json.loads(stock)

# aumento tiene la esttructura de:
# [0] => cant. aumento en mote
# [1] => cant. aumento en huesillo
# [2] => cant. aumento en chancaca
# retorna True si pudo modificar, en caso contrario False(que se debería a falta de stock)
def modifyStock(email, aumento):
 cur = conn.cursor()
 curStock = getStock(email)
 newMote = int(curStock["mote"]) + aumento[0]
 newHuesillo = int(curStock["huesillo"]) + aumento[1]
 newChancaca = int(curStock["chancaca"]) + aumento[2]

 if newMote < 0 or newHuesillo < 0 or newChancaca < 0:
   return False # no podrá modificar por falta de stock

 newStock = '{"mote": '+str(newMote)+', "huesillo": '+str(newHuesillo)+', "chancaca": '+str(newChancaca)+'}'
  
 
 query = f"UPDATE MH SET  stock = '{newStock}' WHERE email = '{email}'"
 cur.execute(query)
 conn.commit()
 cur.close()

 return True


def login(email, pw):
    cursor = conn.cursor()

    consulta = f"SELECT * FROM MH WHERE email = '{str(email)}' and password = '{str(pw)}'"

    cursor.execute(consulta)
    resultados = cursor.fetchall()

    #for fila in resultados:
     #print(fila)

    cursor.close()
    
    # se asume que NO hay usuarios repetidos {email, pw}
    return len(resultados) > 0

# escribe op
def writeOp(opid, res):
    cursor = conn.cursor()
  
    consulta = f"INSERT INTO COMMON_OPS (OPID, response, used) VALUES ({opid}, {res}, {False});"
    
    cursor.execute(consulta)
    conn.commit() 

# obtiene datos op, dado su opid. Se supone que es UNICO(puede asociarse a timestamp)
def getOpData(opid):
    cursor = conn.cursor()

    consulta = f"SELECT * FROM COMMON_OPS WHERE OPID = '{opid}'"

    cursor.execute(consulta)
    resultados = cursor.fetchall()

    #for fila in resultados:
     #print(fila)

    cursor.close()

    return resultados

  
# elimina OP, ya se usó.
def usedOp(opid):
  cur = conn.cursor()

  query = f"DELETE FROM COMMON_OPS WHERE OPID = '{opid}'"
  cur.execute(query)
  conn.commit()
  cur.close()

def opExists(opid):
  return len(getOpData(opid)) > 0

def disminuirStock(email, cantidadVenta):

  # el -1 representa la disminucion
  disminucionStockArr = [-1 * config.UNIT_STOCK["mote"] * cantidadVenta,
                         -1 * config.UNIT_STOCK["huesillo"] * cantidadVenta,
                         -1 * config.UNIT_STOCK["chancaca"] * cantidadVenta]
  
  return modifyStock(email, disminucionStockArr)

def getMaxVentas(email):
  userStock = getStock(email)
  soloMote = math.trunc(int(userStock["mote"])/config.UNIT_STOCK["mote"])
  soloHuesillo = math.trunc(int(userStock["huesillo"])/config.UNIT_STOCK["huesillo"])
  soloChancaca = math.trunc(int(userStock["chancaca"])/config.UNIT_STOCK["chancaca"])

  return min(min(soloMote, soloHuesillo), soloChancaca)

def writeHistorial(data):
  cursor = conn.cursor()
  
  nombre = data["nombre"]
  email = data["email"]
  mensaje = data["mensaje"]
  estado = data["estado"]
  fecha = data["fecha"]

  consulta = f"INSERT INTO HISTORIAL_INSCRIPCIONES (nombre, email, mensaje, estado, fecha) VALUES ('{nombre}', '{email}', '{mensaje}', '{estado}', '{fecha}');"

  cursor.execute(consulta)
  conn.commit() 

def sinStock(email):
   return getMaxVentas(email) == 0

'''
LA BD TIENE LAS TABLAS:

- TABLE MH (id SERIAL PRIMARY KEY,  nombre VARCHAR, email VARCHAR, password VARCHAR, ventas BIGINT, stock JSON, usertype VARCHAR)
- TABLE HISTORIAL_INSCRIPCIONES (id SERIAL PRIMARY KEY, nombre VARCHAR, email VARCHAR, mensaje TEXT, estado VARCHAR, fecha VARCHAR)

auxiliar:
- TABLE COMMON_OPS (OPID VARCHAR PRIMARY KEY, response VARCHAR, used BOOLEAN)


'''