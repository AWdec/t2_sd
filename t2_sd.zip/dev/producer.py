from aiokafka import AIOKafkaProducer
import asyncio
import config


async def send_one(topic, msg, pkey):

    producer = AIOKafkaProducer(
        bootstrap_servers=config.BROCKERS[0])
    
    await producer.start()
    try:
        
         await producer.send(topic, str(msg).encode('utf-8'), key=str(pkey).encode('utf-8'))

    finally:
        await producer.stop()


#asyncio.run(send_one('example_topic', 'XD!', 155))

