import datetime
import time
import ast
import numpy as np



def getDate():
    fecha_actual = datetime.date.today()
    fecha_formateada = fecha_actual.strftime("%d/%m/%Y")
    return fecha_formateada

def getTimeStamp():
 return int(time.time())

def deserializeObj(byteData):
   dict_str = byteData.decode("UTF-8")
   return ast.literal_eval(dict_str)

def deserializeStr(byteData):
   return byteData.decode("UTF-8")

def getRandomStr(leng):
   alfabeto = [chr(letra) for letra in range(65, 91)]
   string = ''

   while len(string) < leng:
      string += alfabeto[int(np.random.uniform(0, 25))]
   
   return string

def canParseAsInt(cadena):
    try:
        int(cadena)  # Intenta convertir la cadena a un número entero.
        return True  # Si no se produce una excepción, la conversión fue exitosa y la cadena es un número entero.
    except ValueError:
        return False 
