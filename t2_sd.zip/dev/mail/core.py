import smtplib
import sys
sys.path.append('../')
import config

# Configura los datos de tu cuenta de Gmail

remite = config.mail
contrasena = config.pw

def send(to, subject, body):
    # Configura los datos del correo destinatario
    destinatario = to
    asunto = subject
    cuerpo_del_mensaje = body

    # Crea un servidor SMTP de Gmail
    servidor_smtp = smtplib.SMTP("smtp.gmail.com", 587)

    # Inicia una conexión segura
    servidor_smtp.starttls()

    # Inicia sesión en tu cuenta de Gmail
    servidor_smtp.login(remite, contrasena)

    # Crea el mensaje
    mensaje = f"Subject: {asunto}\n\n{cuerpo_del_mensaje}"

    # Envía el correo
    servidor_smtp.sendmail(remite, destinatario, mensaje)

    # Cierra la conexión con el servidor SMTP
    servidor_smtp.quit()


